# Queen & Prince Store

موقع بسيط لبيع الطلمبات. لتشغيل المشروع:

```
npm install
npm run dev
```
